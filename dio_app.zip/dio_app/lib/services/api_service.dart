import 'package:dio/dio.dart';
import '../models/post.dart';

/// Сервис для работы с JSONPlaceholder API.
/// Инкапсулирует настройку Dio и все сетевые запросы.
class ApiService {
  // Базовый URL API — все запросы идут относительно него
  static const String _baseUrl = 'https://jsonplaceholder.typicode.com';

  late final Dio _dio;

  ApiService() {
    // Настраиваем Dio с базовыми параметрами
    _dio = Dio(
      BaseOptions(
        baseUrl: _baseUrl,
        connectTimeout: const Duration(seconds: 10), // Таймаут подключения
        receiveTimeout: const Duration(seconds: 10), // Таймаут получения данных
        headers: {'Content-Type': 'application/json'},
      ),
    );

    // Добавляем логирование запросов в режиме отладки
    _dio.interceptors.add(
      LogInterceptor(
        requestBody: false,
        responseBody: false,
        logPrint: (obj) => print('[DIO] $obj'),
      ),
    );
  }

  /// Загружает список постов с сервера.
  /// Возвращает список [Post] или выбрасывает [ApiException].
  Future<List<Post>> fetchPosts() async {
    try {
      final response = await _dio.get('/posts');

      // Проверяем статус ответа
      if (response.statusCode == 200) {
        // Парсим JSON-массив в список объектов Post
        final List<dynamic> jsonList = response.data as List<dynamic>;
        return jsonList
            .map((json) => Post.fromJson(json as Map<String, dynamic>))
            .toList();
      } else {
        throw ApiException('Сервер вернул код: ${response.statusCode}');
      }
    } on DioException catch (e) {
      // Преобразуем ошибки Dio в понятные сообщения
      throw ApiException(_handleDioError(e));
    }
  }

  /// Переводит тип ошибки Dio в читаемое сообщение для пользователя.
  String _handleDioError(DioException error) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
        return 'Превышено время ожидания. Проверьте интернет-соединение.';
      case DioExceptionType.connectionError:
        return 'Нет подключения к интернету.';
      case DioExceptionType.badResponse:
        final code = error.response?.statusCode;
        return 'Ошибка сервера (код $code). Попробуйте позже.';
      case DioExceptionType.cancel:
        return 'Запрос был отменён.';
      default:
        return 'Неизвестная ошибка: ${error.message}';
    }
  }
}

/// Исключение для ошибок API — оборачивает сетевые ошибки
/// в понятное сообщение для отображения в UI.
class ApiException implements Exception {
  final String message;
  const ApiException(this.message);

  @override
  String toString() => message;
}
