/// Модель поста из JSONPlaceholder API.
/// Поля соответствуют структуре JSON-ответа сервера.
class Post {
  final int id;
  final int userId;
  final String title;
  final String body;

  const Post({
    required this.id,
    required this.userId,
    required this.title,
    required this.body,
  });

  /// Создаёт объект [Post] из JSON-словаря.
  /// Используется при парсинге ответа сервера.
  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      id: json['id'] as int,
      userId: json['userId'] as int,
      title: json['title'] as String,
      body: json['body'] as String,
    );
  }

  @override
  String toString() => 'Post(id: $id, title: $title)';
}
