import 'package:flutter/material.dart';
import '../models/post.dart';
import '../services/api_service.dart';
import '../widgets/post_card.dart';
import 'post_detail_screen.dart';

/// Главный экран — загружает и отображает список постов с API.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _apiService = ApiService();

  // Future для хранения результата загрузки постов
  late Future<List<Post>> _postsFuture;

  @override
  void initState() {
    super.initState();
    // Запускаем загрузку при инициализации экрана
    _postsFuture = _apiService.fetchPosts();
  }

  /// Перезагружает список постов (pull-to-refresh).
  Future<void> _refresh() async {
    setState(() {
      _postsFuture = _apiService.fetchPosts();
    });
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Посты'),
        centerTitle: true,
        // Кнопка обновления в AppBar
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Обновить',
            onPressed: _refresh,
          ),
        ],
        // Плашка с информацией об источнике данных
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(32),
          child: Container(
            width: double.infinity,
            color: colorScheme.primaryContainer,
            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
            child: Text(
              'Данные: jsonplaceholder.typicode.com',
              style: TextStyle(
                fontSize: 12,
                color: colorScheme.onPrimaryContainer.withOpacity(0.7),
              ),
            ),
          ),
        ),
      ),
      body: FutureBuilder<List<Post>>(
        future: _postsFuture,
        builder: (context, snapshot) {
          // Состояние загрузки
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Загружаем посты...'),
                ],
              ),
            );
          }

          // Состояние ошибки
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.wifi_off_rounded,
                      size: 64,
                      color: colorScheme.error.withOpacity(0.6),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Ошибка загрузки',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      // Отображаем текст ошибки из ApiException
                      snapshot.error.toString(),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ),
                    const SizedBox(height: 24),
                    FilledButton.icon(
                      icon: const Icon(Icons.refresh),
                      label: const Text('Попробовать снова'),
                      onPressed: _refresh,
                    ),
                  ],
                ),
              ),
            );
          }

          // Состояние успеха — отображаем список
          final posts = snapshot.data!;

          return RefreshIndicator(
            onRefresh: _refresh, // Pull-to-refresh жест
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12),
              itemCount: posts.length,
              itemBuilder: (context, index) {
                final post = posts[index];
                return PostCard(
                  post: post,
                  // При нажатии открываем детальный экран
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => PostDetailScreen(post: post),
                      ),
                    );
                  },
                );
              },
            ),
          );
        },
      ),
    );
  }
}
